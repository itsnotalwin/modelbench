// Project Workspace Application
class ProjectWorkspace {
    constructor() {
        this.items = this.loadItems();
        this.activityHistory = this.loadActivityHistory();
        this.currentUser = "Current User";
        this.currentDate = new Date().toISOString().split('T')[0];
        this.rendered = false;
        this.calendarMonth = new Date().getMonth();
        this.calendarYear = new Date().getFullYear();
        this.currentSort = { column: null, direction: 'asc' };
        this.currentFilters = {};

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.renderAllViews();
        this.updateStats();
        this.renderCalendar();
        this.renderActivityHistory();
        this.renderTable();

        // Show welcome toast
        this.showToast('Workspace initialized successfully!');
    }

    setupEventListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
            if (e.key === 'n' && e.ctrlKey) {
                e.preventDefault();
                this.showModal('item-modal');
            }
            if (e.key === 'i' && e.ctrlKey) {
                e.preventDefault();
                this.showModal('import-modal');
            }
        });

        // Drag and drop for kanban
        this.setupDragAndDrop();
    }

    // Core CRUD Operations

    addItem(itemData) {
        const item = {
            id: Date.now().toString(),
            title: itemData.title || 'Untitled Item',
            description: itemData.description || '',
            status: itemData.status || 'todo',
            priority: itemData.priority || 'medium',
            project: itemData.project || 'General',
            owner: itemData.owner || this.currentUser,
            dueDate: itemData.dueDate || '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: this.currentUser,
            tags: itemData.tags || [],
            dependencies: itemData.dependencies || []
        };

        this.items.unshift(item);
        this.saveItems();
        this.addActivity('created', 'Item created', `${item.title} was created in project ${item.project}`, item.id);
        this.updateStats();
        this.renderAllViews();
        this.showToast('Item created successfully!');
    }

    updateItem(itemId, updates) {
        const index = this.items.findIndex(item => item.id === itemId);
        if (index === -1) return;

        const oldItem = { ...this.items[index] };
        this.items[index] = { ...this.items[index], ...updates, updatedAt: new Date().toISOString() };
        this.saveItems();

        // Check for changes
        const changes = [];
        for (const key in updates) {
            if (oldItem[key] !== this.items[index][key]) {
                changes.push(`${key}: ${oldItem[key]} → ${updates[key]}`);
            }
        }

        if (changes.length > 0) {
            this.addActivity('updated', 'Item updated', `${this.items[index].title} updated: ${changes.join(', ')}`, itemId);
        }

        this.renderAllViews();
        this.updateStats();
        this.showToast('Item updated successfully!');
    }

    deleteItem(itemId) {
        const item = this.items.find(item => item.id === itemId);
        if (!item) return;

        this.items = this.items.filter(item => item.id !== itemId);
        this.saveItems();
        this.addActivity('deleted', 'Item deleted', `${item.title} was deleted`, itemId);
        this.renderAllViews();
        this.updateStats();
        this.showToast('Item deleted successfully!');
    }

    // View Rendering

    renderAllViews() {
        this.renderBoard();
        this.renderTable();
        this.renderCalendar();
        this.renderActivityHistory();
    }

    renderBoard() {
        const board = document.getElementById('kanban-board');
        const filteredItems = this.getFilteredItems();

        // Clear existing cards (except add card placeholders)
        document.querySelectorAll('.kanban-column').forEach(column => {
            column.innerHTML = column.querySelector('.add-card').outerHTML;
        });

        // Group items by status
        const statusGroups = {};
        filteredItems.forEach(item => {
            if (!statusGroups[item.status]) {
                statusGroups[item.status] = [];
            }
            statusGroups[item.status].push(item);
        });

        // Render cards
        Object.keys(statusGroups).forEach(status => {
            const column = document.querySelector(`[data-status="${status}"]`);
            if (!column) return;

            const cardsContainer = column.querySelector('.add-card');
            column.insertBefore(cardsContainer, column.firstChild);

            statusGroups[status].forEach(item => {
                const card = this.createCard(item);
                column.insertBefore(card, cardsContainer);
            });
        });

        // Update counts
        this.updateColumnCounts();
    }

    createCard(item) {
        const card = document.createElement('div');
        card.className = `kanban-card card-priority-${item.priority}`;
        card.draggable = true;
        card.dataset.itemId = item.id;
        card.innerHTML = `
            <div class="card-title">${item.title}</div>
            <div class="card-description">${item.description || 'No description'}</div>
            <div class="card-meta">
                <span class="card-owner">${item.owner}</span>
                <span>${item.project}</span>
            </div>
        `;

        card.addEventListener('click', () => this.showItemDetails(item.id));
        card.addEventListener('dragstart', (e) => this.handleDragStart(e, item.id));

        return card;
    }

    renderTable() {
        const tableBody = document.getElementById('table-body');
        const filteredItems = this.getFilteredItems();
        const sortedItems = this.sortItems(filteredItems);

        if (sortedItems.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="empty-state">No items found. Add some items to get started!</td></tr>';
            return;
        }

        tableBody.innerHTML = sortedItems.map(item => `
            <tr class="table-row" data-item-id="${item.id}">
                <td>${item.title}</td>
                <td>${item.project}</td>
                <td><span class="status-badge status-${item.status}">${item.status.replace('-', ' ')}</span></td>
                <td><span class="status-badge" style="background: ${this.getPriorityColor(item.priority)}; color: white;">${item.priority}</span></td>
                <td>${item.owner}</td>
                <td>${item.dueDate || 'No due date'}</td>
                <td>
                    <button class="btn btn-primary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="workspace.showItemDetails('${item.id}')">View</button>
                    <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 0.8rem; margin-left: 5px;" onclick="workspace.editItem('${item.id}')">Edit</button>
                </td>
            </tr>
        `).join('');

        // Add row click handlers
        document.querySelectorAll('.table-row').forEach(row => {
            row.addEventListener('click', (e) => {
                if (!e.target.closest('button')) {
                    const itemId = row.dataset.itemId;
                    this.showItemDetails(itemId);
                }
            });
        });
    }

    renderCalendar() {
        const daysContainer = document.getElementById('calendar-days');
        const calendarTitle = document.getElementById('calendar-title');

        // Update title
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'];
        calendarTitle.textContent = `${monthNames[this.calendarMonth]} ${this.calendarYear}`;

        // Clear container
        daysContainer.innerHTML = '';

        // Get first day of month and number of days
        const firstDay = new Date(this.calendarYear, this.calendarMonth, 1);
        const lastDay = new Date(this.calendarYear, this.calendarMonth + 1, 0);
        const startDate = new Date(this.calendarYear, this.calendarMonth, 1);
        const startDayOfWeek = startDate.getDay();
        const totalDays = lastDay.getDate();

        // Create empty cells for days before the 1st
        for (let i = 0; i < startDayOfWeek; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day other-month';
            emptyDay.innerHTML = '';
            daysContainer.appendChild(emptyDay);
        }

        // Create days for the month
        const today = new Date();
        const todayStr = today.toDateString();

        for (let day = 1; day <= totalDays; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.innerHTML = `
                <div class="day-number">${day}</div>
                <div class="day-cards"></div>
            `;

            const dateStr = new Date(this.calendarYear, this.calendarMonth, day).toDateString();
            if (dateStr === todayStr) {
                dayElement.classList.add('today');
            }

            // Add items for this day
            const dayItems = this.items.filter(item => {
                if (!item.dueDate) return false;
                const itemDate = new Date(item.dueDate).toDateString();
                return itemDate === dateStr;
            });

            const cardsContainer = dayElement.querySelector('.day-cards');
            dayItems.forEach(item => {
                const card = document.createElement('div');
                card.className = 'day-card';
                card.textContent = item.title;
                card.title = item.title;
                card.onclick = () => this.showItemDetails(item.id);
                cardsContainer.appendChild(card);
            });

            daysContainer.appendChild(dayElement);
        }
    }

    renderActivityHistory() {
        const historyContainer = document.getElementById('activity-history');
        const recentActivity = this.activityHistory.slice(-20).reverse(); // Show last 20 items

        historyContainer.innerHTML = recentActivity.map(activity => `
            <div class="activity-item">
                <div>
                    <span class="activity-action">${this.getActivityAction(activity.action)}</span>
                    <span class="activity-details">${activity.details}</span>
                </div>
                <div class="activity-time">${this.getRelativeTime(activity.timestamp)}</div>
            </div>
        `).join('');
    }

    // Drag and Drop

    setupDragAndDrop() {
        let draggedItemId = null;

        document.querySelectorAll('.kanban-card').forEach(card => {
            card.addEventListener('dragstart', (e) => {
                this.handleDragStart(e, card.dataset.itemId);
                card.classList.add('dragging');
            });

            card.addEventListener('dragend', () => {
                card.classList.remove('dragging');
                document.querySelectorAll('.kanban-column').forEach(col => {
                    col.classList.remove('drag-over');
                });
            });
        });

        document.querySelectorAll('.kanban-column').forEach(column => {
            column.addEventListener('dragover', (e) => {
                e.preventDefault();
                column.classList.add('drag-over');
            });

            column.addEventListener('dragleave', () => {
                column.classList.remove('drag-over');
            });

            column.addEventListener('drop', (e) => {
                e.preventDefault();
                const status = column.dataset.status;
                column.classList.remove('drag-over');

                if (draggedItemId) {
                    this.updateItem(draggedItemId, { status });
                    this.addActivity('status-changed', 'Status changed', `Item moved to ${status} status`, draggedItemId);
                }

                draggedItemId = null;
            });
        });
    }

    handleDragStart(e, itemId) {
        e.dataTransfer.setData('text/plain', itemId);
        e.dataTransfer.effectAllowed = 'move';
    }

    // Search and Filters

    getFilteredItems() {
        let filtered = [...this.items];

        // Apply search filter
        const searchTerm = document.getElementById('board-search')?.value.toLowerCase() || '';
        if (searchTerm) {
            filtered = filtered.filter(item =>
                item.title.toLowerCase().includes(searchTerm) ||
                item.description.toLowerCase().includes(searchTerm) ||
                item.project.toLowerCase().includes(searchTerm) ||
                item.owner.toLowerCase().includes(searchTerm)
            );
        }

        // Apply status filter
        const statusFilter = document.getElementById('board-status-filter')?.value;
        if (statusFilter) {
            filtered = filtered.filter(item => item.status === statusFilter);
        }

        // Apply priority filter
        const priorityFilter = document.getElementById('board-priority-filter')?.value;
        if (priorityFilter) {
            filtered = filtered.filter(item => item.priority === priorityFilter);
        }

        return filtered;
    }

    filterBoard() {
        this.renderBoard();
    }

    filterTable() {
        this.renderTable();
    }

    // Sorting

    sortItems(items) {
        if (!this.currentSort.column) return items;

        return items.sort((a, b) => {
            let aVal = a[this.currentSort.column];
            let bVal = b[this.currentSort.column];

            if (aVal < bVal) return this.currentSort.direction === 'asc' ? -1 : 1;
            if (aVal > bVal) return this.currentSort.direction === 'asc' ? 1 : -1;
            return 0;
        });
    }

    sortTable(column) {
        if (this.currentSort.column === column) {
            this.currentSort.direction = this.currentSort.direction === 'asc' ? 'desc' : 'asc';
        } else {
            this.currentSort.column = column;
            this.currentSort.direction = 'asc';
        }

        this.renderTable();
        this.updateSortIndicators();
    }

    updateSortIndicators() {
        document.querySelectorAll('th').forEach(th => {
            const column = th.textContent.toLowerCase().replace(' ', '');
            if (column === this.currentSort.column) {
                th.style.background = this.currentSort.direction === 'asc' ? '#e3f2fd' : '#fff3e0';
            } else {
                th.style.background = '';
            }
        });
    }

    // Data Management

    saveItems() {
        localStorage.setItem('workspace-items', JSON.stringify(this.items));
    }

    loadItems() {
        const saved = localStorage.getItem('workspace-items');
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (e) {
                console.error('Failed to parse saved items:', e);
                return this.getInitialItems();
            }
        }
        return this.getInitialItems();
    }

    saveActivityHistory() {
        localStorage.setItem('workspace-activity', JSON.stringify(this.activityHistory));
    }

    loadActivityHistory() {
        const saved = localStorage.getItem('workspace-activity');
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (e) {
                console.error('Failed to parse activity history:', e);
                return [];
            }
        }
        return [];
    }

    getInitialItems() {
        return [
            {
                id: '1',
                title: 'Design new dashboard',
                description: 'Create wireframes and mockups for the new admin dashboard',
                status: 'in-progress',
                priority: 'high',
                project: 'Project A',
                owner: 'Alice Johnson',
                dueDate: '2024-01-15',
                createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Alice Johnson',
                tags: ['design', 'frontend'],
                dependencies: []
            },
            {
                id: '2',
                title: 'API integration testing',
                description: 'Test all third-party API integrations',
                status: 'todo',
                priority: 'medium',
                project: 'Project B',
                owner: 'Bob Smith',
                dueDate: '2024-01-20',
                createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Bob Smith',
                tags: ['testing', 'backend'],
                dependencies: ['1']
            },
            {
                id: '3',
                title: 'User onboarding flow',
                description: 'Implement and optimize user registration and first-login process',
                status: 'done',
                priority: 'low',
                project: 'Project C',
                owner: 'Carol Lee',
                dueDate: '2024-01-10',
                createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Carol Lee',
                tags: ['onboarding', 'product'],
                dependencies: []
            },
            {
                id: '4',
                title: 'Security audit',
                description: 'Conduct security review and fix vulnerabilities',
                status: 'review',
                priority: 'high',
                project: 'Project A',
                owner: 'David Brown',
                dueDate: '2024-01-14',
                createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'David Brown',
                tags: ['security', 'audit'],
                dependencies: ['1']
            },
            {
                id: '5',
                title: 'Performance optimization',
                description: 'Optimize application performance and loading times',
                status: 'todo',
                priority: 'medium',
                project: 'Project B',
                owner: 'Alice Johnson',
                dueDate: '2024-01-25',
                createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Alice Johnson',
                tags: ['performance', 'backend'],
                dependencies: []
            },
            {
                id: '6',
                title: 'Documentation update',
                description: 'Update API documentation and user guides',
                status: 'in-progress',
                priority: 'low',
                project: 'Project C',
                owner: 'Eve Williams',
                dueDate: '2024-01-30',
                createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Eve Williams',
                tags: ['documentation', 'content'],
                dependencies: ['2', '5']
            },
            {
                id: '7',
                title: 'Mobile app design',
                description: 'Design responsive mobile application interface',
                status: 'todo',
                priority: 'high',
                project: 'Project A',
                owner: 'Frank Miller',
                dueDate: '2024-02-05',
                createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Frank Miller',
                tags: ['mobile', 'design'],
                dependencies: []
            },
            {
                id: '8',
                title: 'Database migration',
                description: 'Migrate legacy database to new schema',
                status: 'done',
                priority: 'high',
                project: 'Project B',
                owner: 'Grace Lee',
                dueDate: '2024-01-08',
                createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Grace Lee',
                tags: ['database', 'devops'],
                dependencies: []
            },
            {
                id: '9',
                title: 'Customer feedback analysis',
                description: 'Analyze user feedback and identify improvement areas',
                status: 'review',
                priority: 'medium',
                project: 'Project C',
                owner: 'Henry Clark',
                dueDate: '2024-01-12',
                createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
ignite\", part of а (@ciao!)",
                tags: ['analysis', 'product'],
                dependencies: []
            },
            {
                id: '10',
                title: 'Release preparation',
                description: 'Final preparation for product release',
                status: 'todo',
                priority: 'high',
                project: 'General',
                owner: 'Alice Johnson',
                dueDate: '2024-01-31',
                createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
                updatedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
                createdBy: 'Alice Johnson',
                tags: ['release', 'planning'],
                dependencies: ['6', '9']
            }
        ];
    }

    addActivity(action, title, details, itemId) {
        this.activityHistory.unshift({
            id: Date.now().toString(),
            action,
            title,
            details,
            itemId,
            timestamp: new Date().toISOString(),
            user: this.currentUser
        });

        this.saveActivityHistory();
        this.renderActivityHistory();
    }

    getActivityAction(action) {
        const actions = {
            'created': '✓ Created',
            'updated': '✏️ Updated',
            'deleted': '🗑️ Deleted',
            'status-changed': '🔄 Moved',
            'imported': '📥 Imported',
            'exported': '📤 Exported'
        };
        return actions[action] || action;
    }

    getRelativeTime(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diffMs = now - time;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 7) return `${diffDays}d ago`;
        return time.toLocaleDateString();
    }

    getPriorityColor(priority) {
        const colors = {
            'high': '#dc3545',
            'medium': '#ffc107',
            'low': '#28a745'
        };
        return colors[priority] || '#6c757d';
    }

    updateColumnCounts() {
        const statusGroups = {};
        this.items.forEach(item => {
            statusGroups[item.status] = (statusGroups[item.status] || 0) + 1;
        });

        document.querySelectorAll('.column-count').forEach(count => {
            count.textContent = '0';
        });

        Object.keys(statusGroups).forEach(status => {
            const countEl = document.getElementById(`${status}-count`);
            if (countEl) {
                countEl.textContent = statusGroups[status];
            }
        });
    }

    updateStats() {
        // Update any statistics or counters
        this.updateColumnCounts();
    }

    // Modal Management

    showModal(modalId, itemData = null) {
        const modal = document.getElementById(modalId);
        if (!modal) return;

        if (itemData && modalId === 'item-modal') {
            this.populateItemForm(itemData);
        } else {
            this.resetItemForm();
        }

        modal.classList.add('active');
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('active');
        });
    }

    populateItemForm(itemData) {
        if (itemData) {
            document.getElementById('item-title').value = itemData.title || '';
            document.getElementById('item-description').value = itemData.description || '';
            document.getElementById('item-status').value = itemData.status || 'todo';
            document.getElementById('item-priority').value = itemData.priority || 'medium';
            document.getElementById('item-project').value = itemData.project || 'General';
            document.getElementById('item-owner').value = itemData.owner || this.currentUser;
            document.getElementById('item-due-date').value = itemData.dueDate || '';
        }
    }

    resetItemForm() {
        document.getElementById('item-title').value = '';
        document.getElementById('item-description').value = '';
        document.getElementById('item-status').value = 'todo';
        document.getElementById('item-priority').value = 'medium';
        document.getElementById('item-project').value = 'General';
        document.getElementById('item-owner').value = this.currentUser;
        document.getElementById('item-due-date').value = '';
        document.getElementById('item-id').value = '';
    }

    saveItem() {
        const formData = {
            title: document.getElementById('item-title').value,
            description: document.getElementById('item-description').value,
            status: document.getElementById('item-status').value,
            priority: document.getElementById('item-priority').value,
            project: document.getElementById('item-project').value,
            owner: document.getElementById('item-owner').value,
            dueDate: document.getElementById('item-due-date').value,
            tags: document.getElementById('item-tags').value.split(',').map(t => t.trim()).filter(t => t)
        };

        const itemId = document.getElementById('item-id').value;

        if (itemId) {
            this.updateItem(itemId, formData);
        } else {
            this.addItem(formData);
        }

        this.closeAllModals();
    }

    editItem(itemId) {
        const item = this.items.find(item => item.id === itemId);
        if (!item) return;

        this.showModal('item-modal', item);
    }

    showItemDetails(itemId) {
        const item = this.items.find(item => item.id === itemId);
        if (!item) return;

        this.showModal('details-modal', item);
    }

    // Import/Export

    exportData() {
        const data = {
            items: this.items,
            activityHistory: this.activityHistory,
            exportedAt: new Date().toISOString(),
            version: '1.0'
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `workspace__NORTH MINI CODE__TODAYS DATE__v1.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.addActivity('exported', 'Data exported', 'Workspace data was exported as JSON', '');
        this.showToast('Data exported successfully!');
    }

    handleImport(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);

                // Validate the imported data structure
                if (!data.items || !Array.isArray(data.items)) {
                    throw new Error('Invalid workspace data format');
                }

                // Confirm before replacing data
                if (confirm('This will replace your current workspace data. Are you sure?')) {
                    this.items = data.items || [];
                    this.activityHistory = data.activityHistory || [];
                    this.saveItems();
                    this.saveActivityHistory();
                    this.addActivity('imported', 'Data imported', `Workspace data was imported successfully`, '');
                    this.renderAllViews();
                    this.showToast('Data imported successfully!');
                }
            } catch (error) {
                console.error('Import error:', error);
                this.showToast('Import failed: Invalid JSON file', 'error');
            }
        };

        reader.readAsText(file);
        event.target.value = ''; // Reset file input
    }

    // Calendar navigation

    changeMonth(delta) {
        this.calendarMonth += delta;
        if (this.calendarMonth < 0) {
            this.calendarYear--;
            this.calendarMonth = 11;
        } else if (this.calendarMonth > 11) {
            this.calendarYear++;
            this.calendarMonth = 0;
        }
        this.renderCalendar();
    }

    // Toast notifications

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('show');
        }, 100);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }

    // View switching

    switchView(viewName) {
        // Hide all views
        document.querySelectorAll('.view-container').forEach(view => {
            view.classList.remove('active');
        });

        // Remove active class from all nav tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // Show selected view
        document.getElementById(`${viewName}-view`).classList.add('active');

        // Add active class to clicked tab
        event.target.classList.add('active');
    }

    // Keyboard accessibility for drag and drop

    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Delete') {
                const selectedItems = document.querySelectorAll('.kanban-card.selected');
                selectedItems.forEach(card => {
                    const itemId = card.dataset.itemId;
                    if (itemId) {
                        this.deleteItem(itemId);
                    }
                });
            }
        });
    }
}

// Initialize the application
const workspace = new ProjectWorkspace();

// Global functions for HTML onclick handlers
function showModal(modalId, itemData = null) {
    workspace.showModal(modalId, itemData);
}

function closeModal(modalId) {
    workspace.closeAllModals();
}

function saveItem() {
    workspace.saveItem();
}

function editItem(itemId) {
    workspace.editItem(itemId);
}

function showItemDetails(itemId) {
    workspace.showItemDetails(itemId);
}

function exportData() {
    workspace.exportData();
}

function handleImport(event) {
    workspace.handleImport(event);
}

function switchView(viewName) {
    workspace.switchView(viewName);
}

function changeMonth(delta) {
    workspace.changeMonth(delta);
}

function filterBoard() {
    workspace.filterBoard();
}

function filterTable() {
    workspace.filterTable();
}

function sortTable(column) {
    workspace.sortTable(column);
}

function closeAllModals() {
    workspace.closeAllModals();
}

// Initialize keyboard navigation
workspace.setupKeyboardNavigation();
