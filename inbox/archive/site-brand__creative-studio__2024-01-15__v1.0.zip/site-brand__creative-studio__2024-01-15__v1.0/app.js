document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuToggle?.addEventListener('click', function() {
        navLinks?.classList.toggle('active');
        this.classList.toggle('active');
    });
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function() {
            navLinks?.classList.remove('active');
            mobileMenuToggle?.classList.remove('active');
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                window.scrollTo({
                    top: target.offsetTop - headerHeight,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Form validation and submission
    const contactForm = document.getElementById('contactForm');
    const formSuccess = document.getElementById('formSuccess');
    
    // Store form data in localStorage
    function saveFormData() {
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            service: document.getElementById('service').value,
            budget: document.getElementById('budget').value,
            message: document.getElementById('message').value,
            timestamp: new Date().toISOString()
        };
        
        // Store in localStorage for persistence
        localStorage.setItem('lumenlab_form_data', JSON.stringify(formData));
        
        // Store in a simulated server (for demo purposes)
        const submissions = JSON.parse(localStorage.getItem('lumenlab_submissions')) || [];
        submissions.push(formData);
        localStorage.setItem('lumenlab_submissions', JSON.stringify(submissions));
    }
    
    // Load saved form data
    function loadFormData() {
        const savedData = localStorage.getItem('lumenlab_form_data');
        if (savedData) {
            const formData = JSON.parse(savedData);
            document.getElementById('name').value = formData.name || '';
            document.getElementById('email').value = formData.email || '';
            document.getElementById('phone').value = formData.phone || '';
            document.getElementById('service').value = formData.service || '';
            document.getElementById('budget').value = formData.budget || '';
            document.getElementById('message').value = formData.message || '';
        }
    }
    
    // Reset form
    function resetForm() {
        contactForm.reset();
        formSuccess.style.display = 'none';
        contactForm.style.display = 'block';
        // Clear saved data
        localStorage.removeItem('lumenlab_form_data');
    }
    
    // Custom validation functions
    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function validateName(name) {
        return name.trim().length >= 2 && name.trim().length <= 50;
    }
    
    function validateMessage(message) {
        return message.trim().length >= 10 && message.trim().length <= 1000;
    }
    
    // Form validation on input
    document.querySelectorAll('#contactForm input, #contactForm select, #contactForm textarea').forEach(field => {
        field.addEventListener('input', function() {
            validateField(this);
        });
        
        field.addEventListener('blur', function() {
            validateField(this);
        });
    });
    
    // Privacy checkbox validation
    const privacyCheckbox = document.getElementById('privacy');
    privacyCheckbox?.addEventListener('change', function() {
        validateField(this);
    });
    
    function validateField(field) {
        const errorElement = document.getElementById(field.id + '-error');
        let isValid = true;
        let errorMessage = '';
        
        if (field.hasAttribute('required') && !field.value.trim()) {
            isValid = false;
            errorMessage = field.type === 'checkbox' ? 'You must agree to the privacy policy' : 'This field is required';
        } else if (field.type === 'email' && field.value.trim()) {
            if (!validateEmail(field.value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }
        } else if (field.id === 'name' && field.value.trim()) {
            if (!validateName(field.value)) {
                isValid = false;
                errorMessage = 'Name must be between 2 and 50 characters';
            }
        } else if (field.id === 'message' && field.value.trim()) {
            if (!validateMessage(field.value)) {
                isValid = false;
                errorMessage = 'Message must be between 10 and 1000 characters';
            }
        }
        
        if (!isValid) {
            field.setAttribute('aria-invalid', 'true');
            field.classList.add('error');
            if (errorElement) {
                errorElement.textContent = errorMessage;
                errorElement.style.display = 'block';
            }
        } else {
            field.removeAttribute('aria-invalid');
            field.classList.remove('error');
            if (errorElement) {
                errorElement.style.display = 'none';
            }
        }
        
        return isValid;
    }
    
    // Form submission
    contactForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate all required fields
        let isFormValid = true;
        const requiredFields = contactForm.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!validateField(field)) {
                isFormValid = false;
            }
        });
        
        if (isFormValid) {
            // Show loading state
            const submitBtn = contactForm.querySelector('.submit-btn');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            // Save form data
            saveFormData();
            
            // Simulate API call with setTimeout
            setTimeout(() => {
                // Hide form and show success message
                contactForm.style.display = 'none';
                formSuccess.style.display = 'block';
                formSuccess.classList.add('fade-in');
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Scroll to success message
                formSuccess.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 2000);
        }
    });
    
    // Load saved form data on page load
    loadFormData();
    
    // Add scroll reveal animation for sections
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe all sections
    document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
    });
    
    // Handle browser back/forward navigation
    window.addEventListener('popstate', function(e) {
        // If user came back to the page, reload form data
        loadFormData();
    });
    
    // Add reduced motion support
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (prefersReducedMotion.matches) {
        // Disable animations
        const style = document.createElement('style');
        style.textContent = `\n            *, *::before, *::after {\n                animation-duration: 0.01ms !important;\n                animation-iteration-count: 1 !important;\n                transition-duration: 0.01ms !important;\n                scroll-behavior: auto !important;\n            }\n        `;
        document.head.appendChild(style);
    }
    
    // Performance monitoring (basic)
    window.addEventListener('load', function() {
        setTimeout(() => {
            const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
            console.log('Page loaded in', loadTime, 'ms');
            
            // Store performance metrics
            const metrics = {
                loadTime: loadTime,
                timestamp: new Date().toISOString()
            };
            
            const perfData = JSON.parse(localStorage.getItem('lumenlab_performance')) || [];
            perfData.push(metrics);
            localStorage.setItem('lumenlab_performance', JSON.stringify(perfData));
        }, 0);
    });
});